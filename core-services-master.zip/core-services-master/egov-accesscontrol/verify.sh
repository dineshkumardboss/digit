#!/usr/bin/env bash
./mvnw clean test verify
