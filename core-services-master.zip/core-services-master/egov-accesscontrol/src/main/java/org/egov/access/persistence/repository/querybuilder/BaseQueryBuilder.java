package org.egov.access.persistence.repository.querybuilder;

public interface BaseQueryBuilder {
    String build();
}
