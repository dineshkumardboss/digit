ALTER TABLE  egdu_uploadregistry ALTER COLUMN  createdby  TYPE varchar(512);
ALTER TABLE  egdu_uploadregistry ALTER COLUMN  lastmodifiedby  TYPE varchar(512);