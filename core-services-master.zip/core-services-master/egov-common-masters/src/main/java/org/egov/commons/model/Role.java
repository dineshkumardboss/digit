package org.egov.commons.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;
@Builder
@Value
@AllArgsConstructor
public class Role {
	private String name;
}
