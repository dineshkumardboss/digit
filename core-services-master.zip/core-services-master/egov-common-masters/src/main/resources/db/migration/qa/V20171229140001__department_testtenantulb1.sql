INSERT INTO eg_department (id, name, code, active, tenantid) VALUES (1, 'ADMINISTRATION', 'ADM', true, 'testtenant.ulb1');
