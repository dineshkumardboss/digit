INSERT INTO eg_department (id, name, code, active, tenantid) VALUES (nextval('seq_eg_department'), 'ADMINISTRATION', 'ADM', true, 'panavel');
INSERT INTO eg_department (id, name, code, active, tenantid) VALUES (nextval('seq_eg_department'), 'ENGINEERING', 'ENG', true, 'panavel');

