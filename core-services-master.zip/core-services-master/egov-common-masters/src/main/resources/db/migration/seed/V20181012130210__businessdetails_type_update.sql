update eg_businessdetails set businesstype='MISCELLANEOUS' where businesstype='ADHOC';


