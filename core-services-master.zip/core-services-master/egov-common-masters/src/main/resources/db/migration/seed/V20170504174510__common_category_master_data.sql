insert into eg_category(id,name,description,active,tenantid) values(nextval('seq_eg_category'),'BC','Backward Caste',true,'default');
insert into eg_category(id,name,description,active,tenantid) values(nextval('seq_eg_category'),'OC','Open Category',true,'default');
