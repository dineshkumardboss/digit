insert into eg_holidaytype values(nextval('seq_eg_holidaytype'),'General Holiday','default');
insert into eg_holidaytype values(nextval('seq_eg_holidaytype'),'Optional Holiday','default');
insert into eg_holidaytype values(nextval('seq_eg_holidaytype'),'Other Holidays','default');

