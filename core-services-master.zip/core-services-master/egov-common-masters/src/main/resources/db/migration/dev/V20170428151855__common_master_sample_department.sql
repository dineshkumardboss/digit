INSERT INTO eg_department (id, name, code, active, tenantid) VALUES (nextval('seq_eg_department'), 'ADMINISTRATION', 'ADM', true, 'default');
INSERT INTO eg_department (id, name, code, active, tenantid) VALUES (nextval('seq_eg_department'), 'ACCOUNTS', 'ACC', true, 'default');
