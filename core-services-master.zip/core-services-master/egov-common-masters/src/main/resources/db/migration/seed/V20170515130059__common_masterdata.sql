insert into eg_language(id,name,description,active,tenantid) values(nextval('seq_eg_language'),'Others','Others',true,'default');
insert into eg_religion(id,name,description,active,tenantid) values(nextval('seq_eg_religion'),'Others','Others',true,'default');
