update eg_businesscategory set name = 'New Trade License Fee' where code = 'TRADELICENSE' and tenantid = 'default';

update eg_businessdetails set name = 'New Trade License Fee' where code = 'TRADELICENSE' and tenantid = 'default';
update eg_businessdetails set name = 'New Trade Application Fee' where code = 'TLAPPLNFEE' and tenantid = 'default';