alter table eg_uom alter column description drop not null;
